import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-co-client',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './co-client.component.html',
  styleUrls: ['./co-client.component.scss']
})
export class CoClientComponent {

}
