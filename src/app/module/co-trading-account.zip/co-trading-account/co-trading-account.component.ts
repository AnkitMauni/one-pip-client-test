import { CommonModule, DatePipe } from '@angular/common';
import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal, NgbModalConfig,  NgbDropdownModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { GlobalService } from 'src/app/services/global.service';
import { ShareService } from 'src/app/services/share.service';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-co-trading-account',
  standalone: true,
  imports: [NgbNavModule,CommonModule,FormsModule,ReactiveFormsModule, NgbDropdownModule],
  templateUrl: './co-trading-account.component.html',
  styleUrls: ['./co-trading-account.component.scss']
})
export class CoTradingAccountComponent implements OnInit {
  startDate:any
  endDate:any
  personalForm!: FormGroup;
  active:any =1
  ChangePassForm!:FormGroup
  balanceForm!:FormGroup
limitForm!: FormGroup;
accountForm!: FormGroup;
cha!: FormGroup;
  countries: string[] = [
    'All Country','Afghanistan', 'Albania', 'Algeria', 'Andorra', 'Angola', 'Argentina', 'Armenia',
  'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 
  'Belarus', 'Belgium', 'Belize', 'Benin', 'Bhutan', 'Bolivia', 'Bosnia and Herzegovina', 
  'Botswana', 'Brazil', 'Brunei', 'Bulgaria', 'Burkina Faso', 'Burundi', 'Cabo Verde', 
  'Cambodia', 'Cameroon', 'Canada', 'Central African Republic', 'Chad', 'Chile', 'China', 
  'Colombia', 'Comoros', 'Congo, Democratic Republic of the', 'Congo, Republic of the', 
  'Costa Rica', 'Croatia', 'Cuba', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 
  'Dominica', 'Dominican Republic', 'East Timor', 'Ecuador', 'Egypt', 'El Salvador', 
  'Equatorial Guinea', 'Eritrea', 'Estonia', 'Eswatini', 'Ethiopia', 'Fiji', 'Finland', 
  'France', 'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana', 'Greece', 'Grenada', 
  'Guatemala', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Honduras', 'Hungary', 
  'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Israel', 'Italy', 
  'Ivory Coast', 'Jamaica', 'Japan', 'Jordan', 'Kazakhstan', 'Kenya', 'Kiribati', 
  'Korea, North', 'Korea, South', 'Kosovo', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia', 
  'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 
  'Madagascar', 'Malawi', 'Malaysia', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 
  'Mauritania', 'Mauritius', 'Mexico', 'Micronesia', 'Moldova', 'Monaco', 'Mongolia', 
  'Montenegro', 'Morocco', 'Mozambique', 'Myanmar', 'Namibia', 'Nauru', 'Nepal', 
  'Netherlands', 'New Zealand', 'Nicaragua', 'Niger', 'Nigeria', 'North Macedonia', 
  'Norway', 'Oman', 'Pakistan', 'Palau', 'Panama', 'Papua New Guinea', 'Paraguay', 
  'Peru', 'Philippines', 'Poland', 'Portugal', 'Qatar', 'Romania', 'Russia', 'Rwanda', 
  'Saint Kitts and Nevis', 'Saint Lucia', 'Saint Vincent and the Grenadines', 'Samoa', 
  'San Marino', 'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Serbia', 
  'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands', 
  'Somalia', 'South Africa', 'South Sudan', 'Spain', 'Sri Lanka', 'Sudan', 'Suriname', 
  'Sweden', 'Switzerland', 'Syria', 'Taiwan', 'Tajikistan', 'Tanzania', 'Thailand', 
  'Togo', 'Tonga', 'Trinidad and Tobago', 'Tunisia', 'Turkey', 'Turkmenistan', 
  'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 
  'United States', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Vatican City', 'Venezuela', 
  'Vietnam', 'Yemen', 'Zambia', 'Zimbabwe'
  ];

  language: string [] = [
    "English",
    "Spanish",
    "French",
    "German",
    "Chinese",
    "Japanese",
    "Korean",
    "Arabic",
    "Portuguese",
    "Russian",
    "Italian",
    "Hindi",
    "Bengali",
    "Punjabi",
    "Urdu",
    "Turkish",
    "Vietnamese",
    "Persian",
    "Polish",
    "Dutch",
    "Greek",
    "Czech",
    "Swedish",
    "Hungarian",
    "Finnish",
    "Danish",
    "Thai",
    "Hebrew",
    "Indonesian",
    "Malay",
    "Romanian",
    "Bulgarian",
    "Slovak",
    "Croatian",
    "Serbian",
    "Norwegian",
    "Lithuanian",
    "Latvian",
    "Estonian",
    "Slovenian",
    "Maltese",
    "Icelandic",
    "Filipino",
    "Swahili",
    "Zulu",
    "Afrikaans"
  ]
  constructor( private share:ShareService,private datePipe: DatePipe,private modalService: NgbModal,private fb: FormBuilder, config: NgbModalConfig, private router:Router,private api: GlobalService) {
    config.backdrop = 'static';
		config.keyboard = false;
    
  }

  

  ngOnInit(): void {

    this.personalForm = this.fb.group({
      name: [''],
      lastName: [''],
      middleName: [''],
      company: [''],
      registered: [''],
      language: [''],
      status: [''],
      idNumber: [''],
      leadCampaign: [''],
      metaQuotesId: [''],
      leadSource: [''],
      email: [''],
      phone: [''],
      country: [''],
      state: [''],
      city: [''],
      zipCode: [''],
      address: [''],
      comment: ['']
    });
  
   this.limitForm = this.fb.group({
    oET:[],
    oE_API:[],
   
   });

   this.balanceForm = this.fb.group({
    operationType: [''] ,
    amount:[''],
    comment: ['']
   });

   this.ChangePassForm = this.fb.group({
    ChangeInvP:[''],
    ChangeMasterP:['']
   });

   this.accountForm = this.fb.group({
    group:[],
    oEA:[],
    oEP:[],
   
   })
    this.getAllTradingUser()
  }
  allModelData:any ={}
  listOpen:any =[]
  openXl(content: any, modelData:any) {

    this.allModelData = modelData
    console.log("this.allModelData",this.allModelData);
    
    this.GET_OPENED()
    this.setDateRange('today')
    const val = {
      name:this.allModelData.NF ,
      lastName: "",
      middleName: "",
      company: "",
      registered: "",
      language: "",
      status: "",
      idNumber: "",
      leadCampaign: "",
      metaQuotesId: "",
      leadSource: "",
      email: "",
      phone: this.allModelData?.P,
      country: this.allModelData?.CY,
      state: this.allModelData.S,
      city: this.allModelData.C,
      zipCode: this.allModelData.Z,
      address: this.allModelData.A,
      comment: " "
    }
    this.personalForm.patchValue(val);
    const limitF = {
      oET: this.allModelData?.oET,
      oE_API:this.allModelData?.oE_API
    }
    this.limitForm.patchValue(limitF);
    const account = {
      group:this.allModelData?.GP,
    oEA:this.allModelData?.oEA,
    oEP:this.allModelData?.oEP,
    oE_API:this.allModelData?.oE_API
    }
    this.accountForm.patchValue(account);

    const balanceF ={
      operationType: 'Balance' ,
    comment: '... put your comment here...'
    }
    this.balanceForm.patchValue(balanceF);
    this.modalService.open(content, { size: 'xl modalone-two lg850', centered: true });
  }

  listOpenObj:any ={}
  GET_OPENED(){
    let obj ={
      ManagerIndex:Number(localStorage.getItem('managerId')),
      Account:this.allModelData.AC
    }

    this.api.GET_OPENED(obj).subscribe({next: (res:any)=>{
      
      this.listOpenObj = res
      this.listOpen = res.lstOPEN
      console.log("dddd",this.listOpen);
    },
    error: (err:any)=>{
      console.log(err);
      
    }})
  }
 
  navigate(val:any){
    this.router.navigateByUrl(val)
  }

  selectedRowIndex:any
  getSelectRow(index:any){
    this.selectedRowIndex = index
  }

  allTradeUser:any =[]
  getAllTradingUser(){
    // this.share.loader(true)
    let data = localStorage.getItem('allTradeUser') || '[]';
    this.allTradeUser = JSON.parse(data)
    let val = Number(localStorage.getItem('managerId'))
    this.api.GET_USERS_ALL(val).subscribe({ next:(res:any)=>{
     
      if(this.allTradeUser){
        this.allTradeUser = res
        localStorage.setItem('allTradeUser',JSON.stringify(this.allTradeUser))
      }
      else if(!this.allTradeUser){
        let data = localStorage.getItem('allTradeUser') || '[]';
        this.allTradeUser = JSON.parse(data)
      }
      
      // this.share.loader(false)
      console.log("this.allTradeUser",this.allTradeUser);
      
    }, error : (err:any)=>{
      console.log(err);
      
      this.share.loader(false)
    }})
  }

  EDIT_USER_FINO(){
    let per = this.personalForm.value
    let  obj = {
      "AC":this.allModelData.AC,
      "NF":per.name,
      "NL":per.lastName,
      "e":per.email,
      "P":per.phone,
      "A":per.address,
      "C":per.country,
      "S":per.state,
      "CY":per.city,
      "Z": per.zipCode,
      "LV":5000,
      "oEA":this.accountForm.value.oEA,
      "oEP":this.accountForm.value.oEP,
      "oET":this.limitForm.value.oET
  }
  this.api.EDIT_USER_FINO(obj).subscribe({ next: (res:any)=>{
    console.log(res,"edit");
    this.getAllTradingUser()
  },
error: (err:any)=>{
  console.log(err);
  
}})
  }

  setDateRange(range: string) {
    const today = new Date();
    console.log("today",today);
    
    let start: Date;
    let end: Date = new Date(); // Ensure 'end' is a new instance of today's date
  
    switch(range) {
      case 'today':
        start = new Date();
        break;
      case 'last3Days':
        start = new Date();
        start.setDate(today.getDate() - 3);
        break;
      case 'lastWeek':
        start = new Date();
        start.setDate(today.getDate() - 7);
        break;
      case 'lastMonth':
        start = new Date();
        start.setMonth(today.getMonth() - 1);
        break;
      case 'last3Months':
        start = new Date();
        start.setMonth(today.getMonth() - 3);
        break;
      case 'last6Months':
        start = new Date();
        start.setMonth(today.getMonth() - 6);
        break;
      case 'allHistory':
        start = new Date(1970, 0, 1); // Arbitrary start date
        break;
      default:
        start = new Date();
    }
  
    this.startDate = formatDate(start, 'yyyy-MM-dd', 'en');
    this.endDate = formatDate(end, 'yyyy-MM-dd', 'en');
    this.GET_CLOSED()
  }
  
 allHistory:any ={}
 allHistoryList:any =[]
  GET_CLOSED(){

    let obj ={
  Account:Number(this.allModelData.AC),
  StartTm:`${this.startDate} 00:00:59`,
  EndTm:`${this.endDate} 11:59:59`,
  ManagerIndex:Number(localStorage.getItem('managerId')),
    }
    console.log(obj);
    
    this.api.GET_CLOSED(obj).subscribe({next:( res:any)=>{
      console.log("ress histoo",res);
      this.allHistory = res
      this.allHistoryList = res.lstCLOSE
    },
      error:(err:any)=>{
        console.log("err",err);
        
      }})
  }

  onCheckboxChange1(event: any, controlName: string): void {
    const isChecked = event.target.checked;
    this.limitForm.get(controlName)?.setValue(isChecked ? 1 : 0);
    console.log("this.limitForm",this.limitForm.value.oET);
    this.ENABLE_TRADING()
  }


  ENABLE_TRADING(){
    let obj={
    Account:Number(this.allModelData.AC),
    Enable_Disable:this.limitForm.value.oET,
    ManagerIndex:Number(localStorage.getItem('managerId')),
    }
    this.api.ENABLE_TRADING(obj).subscribe({next:(res:any)=>{
         console.log(res,"Enabel");
         
    },error:(err:any)=>{
      console.log(err);
      
    }})
  }
  onCheckboxChange(event: any, controlName: string): void {
    const isChecked = event.target.checked;
    this.accountForm.get(controlName)?.setValue(isChecked ? 1 : 0);
    console.log("this.accountForm",this.accountForm.value.oEA);
    console.log("this.accountForm",this.accountForm.value.oEP);
    
  }

  CHANGE_INVESTOR_PASSWORD(){
    let obj ={
     ManagerIndex:Number(localStorage.getItem('managerId')),
     Account:Number(this.allModelData.AC),
     Password:this.limitForm.value.ChangePassForm,
    }
    this.api.CHANGE_INVESTOR_PASSWORD(obj).subscribe({next:(res:any)=>{
      console.log(res,"change");
      
 },error:(err:any)=>{
   console.log(err);
   
 }})
  }

  CHANGE_MASTER_PASSWORD(){
    let obj ={
      Account:Number(this.allModelData.AC),
      Password:this.ChangePassForm.value.ChangeMasterP,
     ManagerIndex:Number(localStorage.getItem('managerId')),
    }
    this.api.CHANGE_MASTER_PASSWORD(obj).subscribe({next:(res:any)=>{
      console.log(res,"change");
      
 },error:(err:any)=>{
   console.log(err);
   
 }})
  }
  
  perationTypes:any = [
    'Balance', 'Credit', 'Charge', 'Correction', 'Bonus', 
    'Commission', 'Dividend', 'Franked Dividend', 'Tax', 
    'SO compensation', 'SO Credit Compensation'
  ];

  operationTypes1: any = [
    'Deposit', 'Withdrawal', 'Deposit from #put your bank', 
    'Withdraw to #put your bank', 'Credit In', 'Credit Out', 
    '... put your comment here...'
  ];
  isCommentSelected = false;

  onOperationTypeChange() {
    const selectedType = this.balanceForm.get('operationType')?.value;
    this.OprationType(selectedType);
  }

  perationTypesVal:any = 'Balance'
  OprationType(type: string) {
    console.log('Selected Operation Type:', type);
    this.perationTypesVal= type
    // Implement your logic here based on the selected operation type
  }
  
 perationTypesVal1:any = 'Deposit'
  onOperationTypeChange1() {
    const selectedType = this.balanceForm.get('comment')?.value;
    this.isCommentSelected = selectedType === '... put your comment here...';
  }
  
  isDropdownOpen:any = false
  toggleDropdown() {
    this.isDropdownOpen = !this.isDropdownOpen;
  }

  selectOption(option: string) {
    if (option === '... put your comment here...') {
      // Set the input value to empty if "put your comment here" is selected
      this.balanceForm.get('comment')?.setValue('... put your comment here...');
    } else {
      // Set the input value to the selected option
      this.balanceForm.get('comment')?.setValue(option);
    }
    this.isDropdownOpen = false; // Close the dropdown after selection
  }

  MAKE_DEPOIST_BALANCE(){
    let obj ={
      Account:Number(this.allModelData.AC),
      Amount: Number(this.balanceForm.value.amount),
      Comment:this.balanceForm.value.comment,
      ManagerIndex:Number(localStorage.getItem('managerId')),
    }
    this.api.MAKE_DEPOIST_BALANCE(obj).subscribe({next:(res:any)=>{
      console.log(res,"change");
      
 },error:(err:any)=>{
   console.log(err);
   
 }})
  }

  MAKE_WITHDRAW_BALANCE(){
    let obj ={
      Account:Number(this.allModelData.AC),
      Amount: Number(this.balanceForm.value.amount),
      Comment:this.balanceForm.value.comment,
      ManagerIndex:Number(localStorage.getItem('managerId')),
    }
    this.api.MAKE_WITHDRAW_BALANCE(obj).subscribe({next:(res:any)=>{
      console.log(res,"change");
      
 },error:(err:any)=>{
   console.log(err);
   
 }})
  }

  MAKE_DEPOIST_CREDIT(){
    let obj ={
      Account:Number(this.allModelData.AC),
      Amount: Number(this.balanceForm.value.amount),
      Comment:this.balanceForm.value.comment,
      ManagerIndex:Number(localStorage.getItem('managerId')),
    }
    this.api.MAKE_DEPOIST_CREDIT(obj).subscribe({next:(res:any)=>{
      console.log(res,"change");
      
 },error:(err:any)=>{
   console.log(err);
   
 }})
  }

  MAKE_WITHDRAW_CREDIT(){
    let obj ={
      Account:Number(this.allModelData.AC),
      Amount: Number(this.balanceForm.value.amount),
      Comment:this.balanceForm.value.comment,
      ManagerIndex:Number(localStorage.getItem('managerId')),
    }
    this.api.MAKE_DEPOIST_CREDIT(obj).subscribe({next:(res:any)=>{
      console.log(res,"change");
      
 },error:(err:any)=>{
   console.log(err);
   
 }})
  }
}