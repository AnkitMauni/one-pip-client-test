import { Component } from '@angular/core';


@Component({
  selector: 'app-footer',
  
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
  currentTab: any = "tab1";
  nvatabc (tab: any){
    this.currentTab = tab
  }
}
